from pwn import *



p = process('./gauntlet03')


gdb.attach(p, gdbscript='''
           ''')

p.interactive()



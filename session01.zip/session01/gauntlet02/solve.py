from pwn import *


p = process('./gauntlet02')


gdb.attach(p, gdbscript='''
           ''')

p.interactive()



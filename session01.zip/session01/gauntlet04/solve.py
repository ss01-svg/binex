from pwn import *


p = process('./gauntlet04')

gdb.attach(p, gdbscript = '''
           ''')

p.interactive()

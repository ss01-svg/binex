from pwn import *

p = process('./gauntlet01')


p.sendline(payload)
p.interactive()
